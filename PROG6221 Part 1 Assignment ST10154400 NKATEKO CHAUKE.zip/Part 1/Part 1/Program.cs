﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.Remoting.Services;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Part_1
{
    class Program
    {

       static ExternalClass objEc = new ExternalClass();

        static void Main(string[] args)
        {
            //code to prompt user for recipe details starts here using a menu
            int choice = 1;
            while(choice==1 || choice==2 || choice==3 || choice==4 || choice==5 || choice== 6) {
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.WriteLine("Welcome to Become A Chef");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("1. The number of ingredients\n"
                    + "2. Display the full recipe\n"
                    + "3. Request of the scaled recipe\n"
                    + "4. Request to reset quantities\n"
                    + "5. Clear data to add new recipe\n" 
                    + "6. Press 6 to exit the application");
                choice= Convert.ToInt32(Console.ReadLine());
            //if statements for the use to call date outside the main method
                if(choice==1) { option1(); }
                else if(choice==2) { option2(); }
                else if(choice==3) { option3(); }
                else if (choice==4) { option4(); }
                else if(choice==5) { option5(); }
                else if(choice ==6) { System.Environment.Exit(0); }
                else
                {
                    Console.WriteLine("Thank you for joining us");
                    Console.ReadLine();
                }
            }
            
        }
        static void option1()
        {
            //Ask user to for the number of ingredients
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Enter number of ingredients: ");
            int numIngredients = int.Parse(Console.ReadLine());
            objEc.Ingredient = new string[numIngredients];
            objEc.Quantity= new double[numIngredients];
            objEc.UnitOfMeasurements = new string[numIngredients];
            objEc.Scale = new double[numIngredients];
            objEc.Showstep=new string[numIngredients];
            
            //use loop for each ingredient and ask for details
            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine($"Ingredient {i + 1}");
                Console.WriteLine("Enter the name");
                objEc.Ingredient[i] = Console.ReadLine();
                Console.WriteLine("Enter the number of quantity: ");
                objEc.Quantity[i] = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the unit measurement: ");
                objEc.UnitOfMeasurements[i] = (Console.ReadLine());
            }
            //ask user for the number of steps, can be any number of steps
            Console.WriteLine("Enter number of steps: ");
            int numSteps = int.Parse(Console.ReadLine());
            objEc.Showstep=new string[numSteps];
            string[] steps = new string[numSteps];
            for (int i = 0; i < numSteps; i++)
            {
                // add the descriptions after the list of steps
                Console.WriteLine($"Step {i + 1}");
                Console.WriteLine("Enter the description: ");
                steps[i] = Console.ReadLine();
                //end colour fonting
                Console.ForegroundColor = ConsoleColor.White;
            }
          
        }
        public static void option2()
        {
            //declare the variables using string to capture the data and display it
            Console.ForegroundColor = ConsoleColor.Yellow;
            string Show = "";
            for (int i = 0;i<objEc.Ingredient.Length; i++)
            {
                Show += "These are the ingredients: " + objEc.Ingredient[i] + "\n" +
                        "These are the quantities: " + objEc.Quantity[i] + "\n" +
                        "These are the measurements: " + objEc.UnitOfMeasurements[i];
            }
            String showStep = "";
            
            for (int i = 0; i < objEc.Showstep.Length; i++) {
                showStep += "These are the steps " + objEc.Showstep[i];
            }
            String scale = "";

            for(int i = 0;i<objEc.Scale.Length; i++)
            {
                scale += "Scaling results here: " + objEc.Scale[i];
            }
            Console.WriteLine(Show + "\n"+showStep +"\n"+scale);
            Console.ForegroundColor = ConsoleColor.White;
        }
        static void option3()
        {

            Console.ForegroundColor = ConsoleColor.Magenta;
            //prompt user to pick any option to scale the recipe
            int Choice2 = 1;
            Console.WriteLine("Enter ");
            Console.WriteLine("1. Half\n" +
                "2. Double\n"
                + "3. Triple\n");
            Choice2 = Convert.ToInt32(Console.ReadLine());
            int num = objEc.Quantity.Length;
            Console.ForegroundColor = ConsoleColor.DarkBlue;
           
            //declear the scale
            objEc.Scale = new double[num];

            //using if statements for each option above together with the for loop
            if (Choice2 == 1)
            {
                for (int i = 0; i < objEc.Ingredient.Length; i++)
                {
                    objEc.Scale[i] = objEc.Quantity[i] * 0.5;
                }
            }
            else if (Choice2 == 2)
            { 
                for (int i = 0; i < objEc.Quantity.Length; i++)
                {
                    objEc.Scale[i] = objEc.Quantity[i] * 2;
                }
            }
            else if(Choice2 == 3)
            {
                for (int i = 0; i < objEc.UnitOfMeasurements.Length; i++)
                {
                    objEc.Scale[i] = objEc.Quantity[i] * 3;
                }
                Console.ReadLine();
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
        static void option4()
        {
            //clears the date for the quantity
            Console.ForegroundColor= ConsoleColor.DarkBlue;
            Console.WriteLine("enter 4 to bring back the menu");
            Console.ForegroundColor = ConsoleColor.White;
            int numIngredients = int.Parse(Console.ReadLine());
            for (int i = 0; i < objEc.Quantity.Length; i++)
            {
                objEc.Quantity[i] = 0;
            }
        }
        static void option5()
        {
            //using font colour
            Console.ForegroundColor = ConsoleColor.Blue;
            //clearing a for loop for the application to clear all data using null
            int numIngredients = int.Parse(Console.ReadLine());
            for (int i = 0; i < objEc.Quantity.Length; i++)
            {
                objEc.Ingredient[i] = null;
                objEc.Quantity[i] = 0;
                objEc.UnitOfMeasurements[i] = null;
            }
           //The user must enter 
            Console.WriteLine("Press 5 enter to bring the menu ");
            
            int numSteps = int.Parse(Console.ReadLine());
            string[] steps = new string[numSteps];
            for (int i = 0; i < numSteps; i++)
            {
                //declare the variable using the array
                steps[i] = null;
            }
            //Console.ForegroundColor = ConsoleColor.White;
        }
        
        
    }
    
}
